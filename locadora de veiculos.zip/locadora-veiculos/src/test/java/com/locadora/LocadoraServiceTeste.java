package com.locadora;

import com.locadora.model.Categoria;
import com.locadora.model.Locacao;
import com.locadora.repository.*;
import com.locadora.service.LocadoraService;
import com.locadora.service.RegraDeNegocioException;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Testes simples sem framework. Execute com ./scripts/test.sh */
public class LocadoraServiceTeste {
    private static int falhas = 0;

    public static void main(String[] args) {
        teste("aluguel marca o veículo como indisponível", () -> {
            var s = novo();
            Locacao l = s.alugar(1, 1, 3);
            igual(false, s.listarVeiculos().get(0).isDisponivel());
            igual(new BigDecimal("270.00"), l.getValorTotal());
        });
        teste("não permite alugar veículo já alugado", () -> {
            var s = novo();
            s.alugar(1, 1, 2);
            erro(() -> s.alugar(1, 1, 2));
        });
        teste("devolução libera o veículo", () -> {
            var s = novo();
            Locacao l = s.alugar(1, 1, 2);
            s.devolver(l.getId(), LocalDate.now().plusDays(2));
            igual(true, s.listarVeiculos().get(0).isDisponivel());
        });
        teste("devolução antecipada não gera desconto", () -> {
            var s = novo();
            Locacao l = s.alugar(1, 1, 5);
            s.devolver(l.getId(), LocalDate.now().plusDays(1));
            igual(new BigDecimal("450.00"), l.getValorTotal());
        });
        teste("atraso cobra 120% da diária por dia", () -> {
            var s = novo();
            Locacao l = s.alugar(1, 1, 2);               // 2 × 90 = 180
            s.devolver(l.getId(), LocalDate.now().plusDays(4)); // + 2 × 108 = 216
            igual(new BigDecimal("396.00"), l.getValorTotal());
        });
        teste("não encerra a mesma locação duas vezes", () -> {
            var s = novo();
            Locacao l = s.alugar(1, 1, 1);
            s.devolver(l.getId(), LocalDate.now().plusDays(1));
            erro(() -> s.devolver(l.getId(), LocalDate.now().plusDays(1)));
        });
        teste("rejeita placa duplicada e CPF inválido", () -> {
            var s = novo();
            erro(() -> s.cadastrarVeiculo("abc1d23", "X", "Y", 2024, Categoria.SUV));
            erro(() -> s.cadastrarCliente("Ana", "123", "", ""));
        });
        if (falhas > 0) { System.out.println(falhas + " teste(s) falharam."); System.exit(1); }
        System.out.println("Todos os testes passaram.");
    }

    private static LocadoraService novo() {
        var s = new LocadoraService(new VeiculoRepository(), new ClienteRepository(), new LocacaoRepository());
        s.cadastrarVeiculo("ABC1D23", "Fiat", "Mobi", 2023, Categoria.ECONOMICO);
        s.cadastrarCliente("Maria", "12345678909", "m@e.com", "");
        return s;
    }

    private static void teste(String nome, Runnable corpo) {
        try { corpo.run(); System.out.println("OK   " + nome); }
        catch (Throwable t) { falhas++; System.out.println("FALHA " + nome + " -> " + t); }
    }

    private static void igual(Object esperado, Object atual) {
        if (!esperado.equals(atual)) throw new AssertionError("esperado " + esperado + " mas foi " + atual);
    }

    private static void erro(Runnable r) {
        try { r.run(); } catch (RegraDeNegocioException e) { return; }
        throw new AssertionError("era esperada RegraDeNegocioException");
    }
}
