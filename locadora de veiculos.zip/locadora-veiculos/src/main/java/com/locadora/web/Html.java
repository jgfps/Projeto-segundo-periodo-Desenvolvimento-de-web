package com.locadora.web;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Utilitários de apresentação: templates, escape de HTML e formatação. */
final class Html {
    private static final Locale PT_BR = Locale.forLanguageTag("pt-BR");
    private static final DateTimeFormatter DATA = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private Html() {}

    static String esc(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    static String moeda(BigDecimal valor) { return NumberFormat.getCurrencyInstance(PT_BR).format(valor); }

    static String data(LocalDate data) { return data == null ? "—" : DATA.format(data); }

    /** Lê um template de src/main/resources/templates. */
    static String template(String nome) {
        try (InputStream in = Html.class.getResourceAsStream("/templates/" + nome + ".html")) {
            if (in == null) throw new IllegalStateException("Template não encontrado: " + nome);
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Substitui {{chave}} pelos valores informados. */
    static String render(String nome, Map<String, String> valores) {
        String html = template(nome);
        for (Map.Entry<String, String> e : valores.entrySet())
            html = html.replace("{{" + e.getKey() + "}}", e.getValue());
        return html;
    }

    /** Decodifica um corpo application/x-www-form-urlencoded. */
    static Map<String, String> formulario(String corpo) {
        Map<String, String> campos = new HashMap<>();
        if (corpo == null || corpo.isBlank()) return campos;
        for (String par : corpo.split("&")) {
            String[] kv = par.split("=", 2);
            campos.put(URLDecoder.decode(kv[0], StandardCharsets.UTF_8),
                    kv.length > 1 ? URLDecoder.decode(kv[1], StandardCharsets.UTF_8) : "");
        }
        return campos;
    }
}
