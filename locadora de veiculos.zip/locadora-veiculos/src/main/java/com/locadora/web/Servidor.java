package com.locadora.web;

import com.locadora.model.Categoria;
import com.locadora.model.Locacao;
import com.locadora.service.LocadoraService;
import com.locadora.service.RegraDeNegocioException;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.Map;
import java.util.concurrent.Executors;

/** Servidor HTTP (JDK puro, sem dependências) com as rotas da aplicação. */
public class Servidor {
    private final LocadoraService service;
    private final Paginas paginas;
    private final int porta;

    public Servidor(LocadoraService service, int porta) {
        this.service = service;
        this.paginas = new Paginas(service);
        this.porta = porta;
    }

    public void iniciar() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(porta), 0);
        server.createContext("/", this::tratar);
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
    }

    private void tratar(HttpExchange ex) throws IOException {
        String metodo = ex.getRequestMethod();
        String caminho = ex.getRequestURI().getPath();
        try {
            if (metodo.equals("GET")) rotaGet(ex, caminho);
            else if (metodo.equals("POST")) rotaPost(ex, caminho);
            else responder(ex, 405, "text/plain; charset=utf-8", "Método não permitido");
        } catch (RegraDeNegocioException e) {
            redirecionar(ex, caminho.equals("/locacoes/devolver") ? "/locacoes" : caminho, "erro", e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            responder(ex, 500, "text/plain; charset=utf-8", "Erro interno do servidor");
        }
    }

    private void rotaGet(HttpExchange ex, String caminho) throws IOException {
        Map<String, String> q = Html.formulario(ex.getRequestURI().getRawQuery());
        String aviso = q.get("aviso"), erro = q.get("erro");
        switch (caminho) {
            case "/" -> html(ex, paginas.inicio(aviso, erro));
            case "/veiculos" -> html(ex, paginas.veiculos(aviso, erro));
            case "/clientes" -> html(ex, paginas.clientes(aviso, erro));
            case "/locacoes" -> html(ex, paginas.locacoes(aviso, erro));
            case "/static/style.css" -> {
                try (InputStream in = Servidor.class.getResourceAsStream("/static/style.css")) {
                    responder(ex, 200, "text/css; charset=utf-8", new String(in.readAllBytes(), StandardCharsets.UTF_8));
                }
            }
            default -> responder(ex, 404, "text/plain; charset=utf-8", "Página não encontrada");
        }
    }

    private void rotaPost(HttpExchange ex, String caminho) throws IOException {
        Map<String, String> f = Html.formulario(new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8));
        switch (caminho) {
            case "/veiculos" -> {
                var v = service.cadastrarVeiculo(f.get("placa"), f.get("marca"), f.get("modelo"),
                        inteiro(f.get("ano"), "Ano"), Categoria.valueOf(f.get("categoria")));
                redirecionar(ex, "/veiculos", "aviso", "Veículo " + v.getPlaca() + " cadastrado.");
            }
            case "/clientes" -> {
                var c = service.cadastrarCliente(f.get("nome"), f.get("cpf"), f.get("email"), f.get("telefone"));
                redirecionar(ex, "/clientes", "aviso", "Cliente " + c.getNome() + " cadastrado.");
            }
            case "/locacoes" -> {
                Locacao l = service.alugar(inteiro(f.get("cliente"), "Cliente"), inteiro(f.get("veiculo"), "Veículo"),
                        inteiro(f.get("dias"), "Dias"));
                redirecionar(ex, "/locacoes", "aviso",
                        "Locação #" + l.getId() + " criada. Total previsto: " + Html.moeda(l.getValorTotal()));
            }
            case "/locacoes/devolver" -> {
                LocalDate data;
                try { data = LocalDate.parse(f.get("data")); }
                catch (Exception e) { throw new RegraDeNegocioException("Data de devolução inválida."); }
                Locacao l = service.devolver(inteiro(f.get("id"), "Locação"), data);
                redirecionar(ex, "/locacoes", "aviso",
                        "Veículo devolvido. Total final: " + Html.moeda(l.getValorTotal()));
            }
            default -> responder(ex, 404, "text/plain; charset=utf-8", "Página não encontrada");
        }
    }

    private static int inteiro(String valor, String campo) {
        try { return Integer.parseInt(valor.trim()); }
        catch (Exception e) { throw new RegraDeNegocioException(campo + " inválido."); }
    }

    private void html(HttpExchange ex, String corpo) throws IOException {
        responder(ex, 200, "text/html; charset=utf-8", corpo);
    }

    private void redirecionar(HttpExchange ex, String destino, String tipo, String mensagem) throws IOException {
        ex.getResponseHeaders().set("Location", destino + "?" + tipo + "=" + URLEncoder.encode(mensagem, StandardCharsets.UTF_8));
        ex.sendResponseHeaders(303, -1);
        ex.close();
    }

    private void responder(HttpExchange ex, int status, String tipo, String corpo) throws IOException {
        byte[] bytes = corpo.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", tipo);
        ex.sendResponseHeaders(status, bytes.length);
        ex.getResponseBody().write(bytes);
        ex.close();
    }
}
