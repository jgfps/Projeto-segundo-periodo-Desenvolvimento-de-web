package com.locadora.web;

import com.locadora.model.*;
import com.locadora.service.LocadoraService;

import java.util.Map;

/** Monta o HTML de cada tela a partir dos templates. */
final class Paginas {
    private final LocadoraService service;

    Paginas(LocadoraService service) { this.service = service; }

    String inicio(String aviso, String erro) {
        String conteudo = Html.render("home", Map.of(
                "totalVeiculos", String.valueOf(service.listarVeiculos().size()),
                "disponiveis", String.valueOf(service.listarVeiculosDisponiveis().size()),
                "ativas", String.valueOf(service.listarLocacoesAtivas().size()),
                "clientes", String.valueOf(service.listarClientes().size())));
        return layout("Painel", "inicio", conteudo, aviso, erro);
    }

    String veiculos(String aviso, String erro) {
        StringBuilder linhas = new StringBuilder();
        for (Veiculo v : service.listarVeiculos()) {
            String status = v.isDisponivel()
                    ? "<span class=\"tag ok\">Disponível</span>" : "<span class=\"tag warn\">Alugado</span>";
            linhas.append("<tr><td>").append(Html.esc(v.getPlaca())).append("</td><td>")
                    .append(Html.esc(v.getDescricao())).append("</td><td>")
                    .append(Html.esc(v.getCategoria().getDescricao())).append("</td><td>")
                    .append(Html.moeda(v.getCategoria().getDiaria())).append("</td><td>")
                    .append(status).append("</td></tr>");
        }
        StringBuilder opcoes = new StringBuilder();
        for (Categoria c : Categoria.values())
            opcoes.append("<option value=\"").append(c.name()).append("\">")
                    .append(Html.esc(c.getDescricao())).append(" — ").append(Html.moeda(c.getDiaria()))
                    .append("/dia</option>");
        String conteudo = Html.render("veiculos", Map.of("linhas", linhas.toString(), "categorias", opcoes.toString()));
        return layout("Veículos", "veiculos", conteudo, aviso, erro);
    }

    String clientes(String aviso, String erro) {
        StringBuilder linhas = new StringBuilder();
        for (Cliente c : service.listarClientes()) {
            String cpf = c.getCpf();
            String cpfFmt = cpf.substring(0, 3) + "." + cpf.substring(3, 6) + "." + cpf.substring(6, 9) + "-" + cpf.substring(9);
            linhas.append("<tr><td>").append(Html.esc(c.getNome())).append("</td><td>").append(cpfFmt)
                    .append("</td><td>").append(Html.esc(c.getEmail())).append("</td><td>")
                    .append(Html.esc(c.getTelefone())).append("</td></tr>");
        }
        return layout("Clientes", "clientes", Html.render("clientes", Map.of("linhas", linhas.toString())), aviso, erro);
    }

    String locacoes(String aviso, String erro) {
        StringBuilder clientes = new StringBuilder();
        for (Cliente c : service.listarClientes())
            clientes.append("<option value=\"").append(c.getId()).append("\">").append(Html.esc(c.getNome())).append("</option>");
        StringBuilder veiculos = new StringBuilder();
        for (Veiculo v : service.listarVeiculosDisponiveis())
            veiculos.append("<option value=\"").append(v.getId()).append("\">").append(Html.esc(v.getPlaca()))
                    .append(" · ").append(Html.esc(v.getDescricao())).append(" (")
                    .append(Html.moeda(v.getCategoria().getDiaria())).append("/dia)</option>");

        StringBuilder linhas = new StringBuilder();
        String hoje = java.time.LocalDate.now().toString();
        for (Locacao l : service.listarLocacoes().reversed()) {
            String acao = l.isAtiva()
                    ? "<form method=\"post\" action=\"/locacoes/devolver\" class=\"inline\">"
                    + "<input type=\"hidden\" name=\"id\" value=\"" + l.getId() + "\">"
                    + "<input type=\"date\" name=\"data\" value=\"" + hoje + "\" required>"
                    + "<button type=\"submit\" class=\"small\">Devolver</button></form>"
                    : "<span class=\"tag\">Encerrada</span>";
            linhas.append("<tr><td>#").append(l.getId()).append("</td><td>")
                    .append(Html.esc(l.getCliente().getNome())).append("</td><td>")
                    .append(Html.esc(l.getVeiculo().getPlaca())).append(" · ")
                    .append(Html.esc(l.getVeiculo().getDescricao())).append("</td><td>")
                    .append(Html.data(l.getRetirada())).append("</td><td>")
                    .append(Html.data(l.getDevolucaoPrevista())).append("</td><td>")
                    .append(Html.data(l.getDevolucaoReal())).append("</td><td>")
                    .append(Html.moeda(l.getValorTotal())).append("</td><td>")
                    .append(acao).append("</td></tr>");
        }
        String conteudo = Html.render("locacoes", Map.of("clientes", clientes.toString(),
                "veiculos", veiculos.toString(), "linhas", linhas.toString()));
        return layout("Locações", "locacoes", conteudo, aviso, erro);
    }

    private String layout(String titulo, String ativo, String conteudo, String aviso, String erro) {
        String[][] menu = {{"inicio", "/", "Painel"}, {"veiculos", "/veiculos", "Veículos"},
                {"clientes", "/clientes", "Clientes"}, {"locacoes", "/locacoes", "Locações"}};
        StringBuilder nav = new StringBuilder();
        for (String[] item : menu)
            nav.append("<a href=\"").append(item[1]).append("\"")
                    .append(item[0].equals(ativo) ? " class=\"ativo\"" : "").append(">").append(item[2]).append("</a>");
        StringBuilder alerta = new StringBuilder();
        if (aviso != null && !aviso.isBlank())
            alerta.append("<div class=\"alerta sucesso\">").append(Html.esc(aviso)).append("</div>");
        if (erro != null && !erro.isBlank())
            alerta.append("<div class=\"alerta erro\">").append(Html.esc(erro)).append("</div>");
        return Html.render("layout", Map.of("titulo", Html.esc(titulo), "nav", nav.toString(),
                "alerta", alerta.toString(), "conteudo", conteudo));
    }
}
