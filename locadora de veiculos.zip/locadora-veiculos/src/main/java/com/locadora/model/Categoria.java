package com.locadora.model;

import java.math.BigDecimal;

public enum Categoria {
    ECONOMICO("Econômico", "90.00"),
    SEDAN("Sedan", "150.00"),
    SUV("SUV", "220.00"),
    LUXO("Luxo", "400.00");

    private final String descricao;
    private final BigDecimal diaria;

    Categoria(String descricao, String diaria) {
        this.descricao = descricao;
        this.diaria = new BigDecimal(diaria);
    }

    public String getDescricao() { return descricao; }
    public BigDecimal getDiaria() { return diaria; }
}
