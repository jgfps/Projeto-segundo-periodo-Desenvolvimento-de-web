package com.locadora.model;

/** Classe base com o identificador, atribuído pelo repositório. */
public abstract class Entidade {
    private long id;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
}
