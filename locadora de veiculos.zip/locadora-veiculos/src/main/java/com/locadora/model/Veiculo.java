package com.locadora.model;

public class Veiculo extends Entidade {
    private final String placa;
    private final String marca;
    private final String modelo;
    private final int ano;
    private final Categoria categoria;
    private boolean disponivel = true;

    public Veiculo(String placa, String marca, String modelo, int ano, Categoria categoria) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.categoria = categoria;
    }

    public String getPlaca() { return placa; }
    public String getMarca() { return marca; }
    public String getModelo() { return modelo; }
    public int getAno() { return ano; }
    public Categoria getCategoria() { return categoria; }
    public boolean isDisponivel() { return disponivel; }
    public void setDisponivel(boolean disponivel) { this.disponivel = disponivel; }

    public String getDescricao() { return marca + " " + modelo + " " + ano; }
}
