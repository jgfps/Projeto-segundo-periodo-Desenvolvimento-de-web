package com.locadora.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Locacao extends Entidade {
    /** Multiplicador da diária aplicado a cada dia de atraso. */
    public static final BigDecimal FATOR_ATRASO = new BigDecimal("1.20");

    private final Veiculo veiculo;
    private final Cliente cliente;
    private final LocalDate retirada;
    private final LocalDate devolucaoPrevista;
    private final BigDecimal diariaAplicada;
    private LocalDate devolucaoReal;
    private BigDecimal valorTotal;

    public Locacao(Veiculo veiculo, Cliente cliente, LocalDate retirada, int dias) {
        this.veiculo = veiculo;
        this.cliente = cliente;
        this.retirada = retirada;
        this.devolucaoPrevista = retirada.plusDays(dias);
        this.diariaAplicada = veiculo.getCategoria().getDiaria();
        this.valorTotal = calcularTotal(devolucaoPrevista);
    }

    /**
     * Total = diária × dias previstos + diária × 1,20 × dias de atraso.
     * Devolver antes do prazo não gera desconto.
     */
    public BigDecimal calcularTotal(LocalDate dataDevolucao) {
        long diasPrevistos = ChronoUnit.DAYS.between(retirada, devolucaoPrevista);
        long atraso = Math.max(0, ChronoUnit.DAYS.between(devolucaoPrevista, dataDevolucao));
        BigDecimal base = diariaAplicada.multiply(BigDecimal.valueOf(diasPrevistos));
        BigDecimal multa = diariaAplicada.multiply(FATOR_ATRASO).multiply(BigDecimal.valueOf(atraso));
        return base.add(multa).setScale(2, RoundingMode.HALF_UP);
    }

    public void encerrar(LocalDate data) {
        this.devolucaoReal = data;
        this.valorTotal = calcularTotal(data);
    }

    public boolean isAtiva() { return devolucaoReal == null; }

    public Veiculo getVeiculo() { return veiculo; }
    public Cliente getCliente() { return cliente; }
    public LocalDate getRetirada() { return retirada; }
    public LocalDate getDevolucaoPrevista() { return devolucaoPrevista; }
    public LocalDate getDevolucaoReal() { return devolucaoReal; }
    public BigDecimal getDiariaAplicada() { return diariaAplicada; }
    public BigDecimal getValorTotal() { return valorTotal; }
}
