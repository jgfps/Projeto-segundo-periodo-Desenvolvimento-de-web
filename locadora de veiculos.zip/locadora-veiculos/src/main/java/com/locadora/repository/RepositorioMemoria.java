package com.locadora.repository;

import com.locadora.model.Entidade;

import java.util.*;

/** Repositório genérico em memória (substituível por JDBC/JPA). */
public class RepositorioMemoria<T extends Entidade> {
    private final Map<Long, T> dados = new LinkedHashMap<>();
    private long sequencia = 0;

    public synchronized T salvar(T entidade) {
        if (entidade.getId() == 0) entidade.setId(++sequencia);
        dados.put(entidade.getId(), entidade);
        return entidade;
    }

    public synchronized Optional<T> buscarPorId(long id) {
        return Optional.ofNullable(dados.get(id));
    }

    public synchronized List<T> listar() {
        return new ArrayList<>(dados.values());
    }
}
