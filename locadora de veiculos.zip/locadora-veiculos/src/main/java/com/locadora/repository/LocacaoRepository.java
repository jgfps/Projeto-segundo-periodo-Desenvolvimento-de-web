package com.locadora.repository;

import com.locadora.model.Locacao;

import java.util.List;

public class LocacaoRepository extends RepositorioMemoria<Locacao> {
    public List<Locacao> listarAtivas() {
        return listar().stream().filter(Locacao::isAtiva).toList();
    }
}
