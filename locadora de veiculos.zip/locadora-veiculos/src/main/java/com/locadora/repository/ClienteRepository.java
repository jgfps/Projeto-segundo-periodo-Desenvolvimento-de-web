package com.locadora.repository;

import com.locadora.model.Cliente;

import java.util.Optional;

public class ClienteRepository extends RepositorioMemoria<Cliente> {
    public Optional<Cliente> buscarPorCpf(String cpf) {
        return listar().stream().filter(c -> c.getCpf().equals(cpf)).findFirst();
    }
}
