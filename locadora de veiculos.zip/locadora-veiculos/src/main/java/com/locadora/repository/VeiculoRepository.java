package com.locadora.repository;

import com.locadora.model.Veiculo;

import java.util.Optional;

public class VeiculoRepository extends RepositorioMemoria<Veiculo> {
    public Optional<Veiculo> buscarPorPlaca(String placa) {
        return listar().stream().filter(v -> v.getPlaca().equalsIgnoreCase(placa)).findFirst();
    }
}
