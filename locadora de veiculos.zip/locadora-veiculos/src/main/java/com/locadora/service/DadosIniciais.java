package com.locadora.service;

import com.locadora.model.Categoria;

/** Popula o sistema com dados de demonstração. */
public final class DadosIniciais {
    private DadosIniciais() {}

    public static void carregar(LocadoraService s) {
        s.cadastrarVeiculo("ABC1D23", "Fiat", "Mobi", 2023, Categoria.ECONOMICO);
        s.cadastrarVeiculo("BRA2E19", "Chevrolet", "Onix", 2024, Categoria.ECONOMICO);
        s.cadastrarVeiculo("PBH4F56", "Toyota", "Corolla", 2023, Categoria.SEDAN);
        s.cadastrarVeiculo("JPA7G89", "Jeep", "Compass", 2024, Categoria.SUV);
        s.cadastrarVeiculo("LUX9H01", "BMW", "320i", 2025, Categoria.LUXO);
        s.cadastrarCliente("Maria Souza", "123.456.789-09", "maria@email.com", "(83) 99999-0001");
        s.cadastrarCliente("João Pereira", "987.654.321-00", "joao@email.com", "(83) 99999-0002");
    }
}
