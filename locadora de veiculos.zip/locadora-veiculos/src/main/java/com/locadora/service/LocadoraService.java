package com.locadora.service;

import com.locadora.model.*;
import com.locadora.repository.*;

import java.time.LocalDate;
import java.util.List;

/** Regras de negócio da locadora. */
public class LocadoraService {
    private final VeiculoRepository veiculos;
    private final ClienteRepository clientes;
    private final LocacaoRepository locacoes;

    public LocadoraService(VeiculoRepository veiculos, ClienteRepository clientes, LocacaoRepository locacoes) {
        this.veiculos = veiculos;
        this.clientes = clientes;
        this.locacoes = locacoes;
    }

    public synchronized Veiculo cadastrarVeiculo(String placa, String marca, String modelo, int ano, Categoria categoria) {
        placa = exigir(placa, "Placa").toUpperCase();
        if (!placa.matches("[A-Z]{3}[0-9][A-Z0-9][0-9]{2}"))
            throw new RegraDeNegocioException("Placa inválida (use AAA1234 ou AAA1A23).");
        if (veiculos.buscarPorPlaca(placa).isPresent())
            throw new RegraDeNegocioException("Já existe um veículo com a placa " + placa + ".");
        if (ano < 2000 || ano > LocalDate.now().getYear() + 1)
            throw new RegraDeNegocioException("Ano do veículo inválido.");
        return veiculos.salvar(new Veiculo(placa, exigir(marca, "Marca"), exigir(modelo, "Modelo"), ano, categoria));
    }

    public synchronized Cliente cadastrarCliente(String nome, String cpf, String email, String telefone) {
        cpf = exigir(cpf, "CPF").replaceAll("\\D", "");
        if (cpf.length() != 11) throw new RegraDeNegocioException("CPF deve ter 11 dígitos.");
        if (clientes.buscarPorCpf(cpf).isPresent())
            throw new RegraDeNegocioException("CPF já cadastrado.");
        return clientes.salvar(new Cliente(exigir(nome, "Nome"), cpf, email == null ? "" : email.trim(),
                telefone == null ? "" : telefone.trim()));
    }

    public synchronized Locacao alugar(long clienteId, long veiculoId, int dias) {
        if (dias < 1 || dias > 90) throw new RegraDeNegocioException("O período deve ser de 1 a 90 dias.");
        Cliente cliente = clientes.buscarPorId(clienteId)
                .orElseThrow(() -> new RegraDeNegocioException("Cliente não encontrado."));
        Veiculo veiculo = veiculos.buscarPorId(veiculoId)
                .orElseThrow(() -> new RegraDeNegocioException("Veículo não encontrado."));
        if (!veiculo.isDisponivel())
            throw new RegraDeNegocioException("O veículo " + veiculo.getPlaca() + " não está disponível.");
        veiculo.setDisponivel(false);
        return locacoes.salvar(new Locacao(veiculo, cliente, LocalDate.now(), dias));
    }

    public synchronized Locacao devolver(long locacaoId, LocalDate dataDevolucao) {
        Locacao locacao = locacoes.buscarPorId(locacaoId)
                .orElseThrow(() -> new RegraDeNegocioException("Locação não encontrada."));
        if (!locacao.isAtiva()) throw new RegraDeNegocioException("Esta locação já foi encerrada.");
        if (dataDevolucao.isBefore(locacao.getRetirada()))
            throw new RegraDeNegocioException("A devolução não pode ser anterior à retirada.");
        locacao.encerrar(dataDevolucao);
        locacao.getVeiculo().setDisponivel(true);
        return locacao;
    }

    public List<Veiculo> listarVeiculos() { return veiculos.listar(); }
    public List<Veiculo> listarVeiculosDisponiveis() {
        return veiculos.listar().stream().filter(Veiculo::isDisponivel).toList();
    }
    public List<Cliente> listarClientes() { return clientes.listar(); }
    public List<Locacao> listarLocacoes() { return locacoes.listar(); }
    public List<Locacao> listarLocacoesAtivas() { return locacoes.listarAtivas(); }

    private static String exigir(String valor, String campo) {
        if (valor == null || valor.isBlank()) throw new RegraDeNegocioException(campo + " é obrigatório.");
        return valor.trim();
    }
}
