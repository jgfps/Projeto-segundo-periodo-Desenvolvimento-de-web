package com.locadora;

import com.locadora.repository.ClienteRepository;
import com.locadora.repository.LocacaoRepository;
import com.locadora.repository.VeiculoRepository;
import com.locadora.service.DadosIniciais;
import com.locadora.service.LocadoraService;
import com.locadora.web.Servidor;

public class Main {
    public static void main(String[] args) throws Exception {
        int porta = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        LocadoraService service = new LocadoraService(
                new VeiculoRepository(), new ClienteRepository(), new LocacaoRepository());
        DadosIniciais.carregar(service);
        new Servidor(service, porta).iniciar();
        System.out.println("Locadora rodando em http://localhost:" + porta);
    }
}
