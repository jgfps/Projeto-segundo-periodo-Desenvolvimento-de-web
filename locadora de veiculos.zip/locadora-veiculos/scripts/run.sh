#!/usr/bin/env bash
# Compila e executa. Uso: ./scripts/run.sh [porta]
set -euo pipefail
cd "$(dirname "$0")/.."
./scripts/build.sh
java -Dfile.encoding=UTF-8 -cp out com.locadora.Main "$@"
