#!/usr/bin/env bash
# Compila e roda os testes
set -euo pipefail
cd "$(dirname "$0")/.."
./scripts/build.sh
mkdir -p out-test
javac -encoding UTF-8 -cp out -d out-test $(find src/test/java -name '*.java')
java -Dfile.encoding=UTF-8 -cp out:out-test com.locadora.LocadoraServiceTeste
