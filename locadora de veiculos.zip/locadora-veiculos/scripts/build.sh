#!/usr/bin/env bash
# Compila o projeto para ./out (requer JDK 21+)
set -euo pipefail
cd "$(dirname "$0")/.."
rm -rf out && mkdir -p out
javac -encoding UTF-8 -d out $(find src/main/java -name '*.java')
cp -r src/main/resources/* out/
echo "Build concluído em ./out"
